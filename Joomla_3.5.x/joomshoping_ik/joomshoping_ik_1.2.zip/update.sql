INSERT INTO `#__jshopping_payment_method` (`name_ru-RU`, `description_ru-RU`,`name_en-GB`, `description_en-GB`, `payment_code`, `payment_class`, `payment_publish`, `payment_ordering`, `payment_params`, `payment_type`, `price`, `price_type`, `tax_id`, `show_descr_in_email`) VALUES

('Интеркасса', '','interkassa', '', 'interkassa', 'pm_interkassa', 1, 0, 'wallet_id=xxxx\nsecret_key=xxxx\nsecret_test_key=xxxxxx\ntransaction_end_status=7\ntransaction_pending_status=1\ntransaction_failed_status=3\n', 2, 0.00, 1, 1, 0);
